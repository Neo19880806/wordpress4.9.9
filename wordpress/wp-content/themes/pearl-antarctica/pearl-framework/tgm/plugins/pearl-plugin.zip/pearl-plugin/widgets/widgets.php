<?php
/**
 * Theme Widgets
 */

/**
 * Advertisement Widget
 */
require_once plugin_dir_path( dirname( __FILE__ ) ) . '/widgets/pearl-ad-widget.php';

/**
 * Recent Posts Widget
 */
require_once plugin_dir_path( dirname( __FILE__ ) ) . '/widgets/pearl-recent-posts-widget.php';